//
//  BannerCell.swift
//  ReminderUItableview
//
//  Created by Badr on 25/03/1443 AH.
//

//import UIKit
//
//class BannerCell: UITableViewCell {
//
//
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//
//}
